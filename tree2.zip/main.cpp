#include <iostream>
#include <queue>
using namespace std;
struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int val) {
        data = val;
        left = right = NULL;
    }
};
void inorder(Node* root) {
    if (root) {
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }
}

void preorder(Node* root) {
    if (root) {
        cout << root->data << " ";
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node* root) {
    if (root) {
        postorder(root->left);
        postorder(root->right);
        cout << root->data << " ";
    }
}

int main() {
    queue<Node*> q;
    int x;
    cin >> x;

    if (x == -1) return 0;

    Node* root = new Node(x);
    q.push(root);

    while (!q.empty()) {
        Node* current = q.front();
        q.pop();

        // Input left child
        cin >> x;
        if (x == -1) break;
        current->left = new Node(x);
        q.push(current->left);

        // Input right child
        cin >> x;
        if (x == -1) break;
        current->right = new Node(x);
        q.push(current->right);
    }

    inorder(root); cout << endl;
    preorder(root); cout << endl;
    postorder(root); cout << endl;

    return 0;
}
