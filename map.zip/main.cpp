#include <iostream>
#include <map>
using namespace std;

int main() {
    // Declare a map from string to int
    map<string, int> ageMap;

    // Insert elements into the map
    ageMap["Alice"] = 25;//1
    ageMap["Bob"] = 30;//2
    ageMap["Charlie"] = 28;//3

    // Access and update value
    ageMap["Bob"] = 32;  // Overwrites the previous value
//3->4
    // Print all elements
    cout << "Name\tAge\n";
    for (auto pair : ageMap) {
        cout << pair.first << "\t" << pair.second << endl;
    }

   
    return 0;
}
