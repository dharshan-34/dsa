#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
    int n;
    cout<<"Enter number of Student:";
    cin>>n;
    vector<int>Scores;
    int mark;
    for(int i=0;i<n;i++){
        cin>>mark;
        Scores.push_back(mark);
    }
        sort(Scores.begin(),Scores.end());
        cout<<"Sorterd Scores:";
        for(int i=0;i<n;i++)
        cout<<Scores[i]<<" ";
    }
    cout<<"Top  Scores:";
    for(int i= n-1; i>=max(0,n-3);i--)
    cout<<Scores[i]<<" ";
}
return 0;
}