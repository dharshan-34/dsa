// ---------- Linear Search ----------

#include <iostream>

#include <vector>

using namespace std;


int linearSearch(vector<int>& arr, int key) {

    for (int i = 0; i < arr.size(); i++) {

        if (arr[i] == key) return i;

    }

    return -1;

}


int main() {

    vector<int> arr = {64, 25, 12, 22, 11};

    int key = 22;

    int index = linearSearch(arr, key);

    cout << "Index of " << key << ": " << index << endl;

    return 0;

}

