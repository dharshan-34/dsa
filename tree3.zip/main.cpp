#include <iostream>
#include <queue>
using namespace std;
struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

int countNodes(Node* root) {
    if (root == NULL) return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}

int main() {
    int x;
    cin >> x;
    if (x == -1) {
        cout << 0 << endl;
        return 0;
    }

    Node* root = new Node(x);
    queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        Node* current = q.front();
        q.pop();

        // Input for left child
        cin >> x;
        if (x != -1) {
            current->left = new Node(x);
            q.push(current->left);
        }

        // Input for right child
        cin >> x;
        if (x != -1) {
            current->right = new Node(x);
            q.push(current->right);
        }
    }

    cout << countNodes(root) << endl;
    return 0;
}